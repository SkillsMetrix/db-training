// AuthResponse.java
package com.example.jwtapp.dto;
import lombok.*;

@Data
@AllArgsConstructor
public class AuthResponse {
    private String token;
}
