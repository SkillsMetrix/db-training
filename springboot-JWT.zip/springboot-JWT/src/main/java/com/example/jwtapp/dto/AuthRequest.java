// AuthRequest.java
package com.example.jwtapp.dto;
import lombok.*;

@Data
public class AuthRequest {
    private String username;
    private String password;
}
