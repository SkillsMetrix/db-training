
 
function addUser(event ){
    event.preventDefault();
  
    
    const name= document.getElementById('username')
     const email= document.getElementById('email')
      const gender= document.getElementById('gender')
       const course= document.getElementById('course')
       //create an object

       const userdata={
        uname:name.value.trim(),
         uemail:email.value.trim(),
            ugender:gender.value.trim(),
              ucourse:course.value.trim()

        }
      
   const tbody= document.querySelector('#tab tbody')
   const row= document.createElement("tr")
   row.innerHTML= `
   <td>${userdata.uname}</td>
    <td>${userdata.uemail}</td>
     <td>${userdata.ugender}</td>
      <td>${userdata.ucourse}</td>
   `
   tbody.appendChild(row)
  
       
}     
 