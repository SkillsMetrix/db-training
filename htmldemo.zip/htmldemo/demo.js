
function showData(){
    const uname=document.getElementById('username').value
     const email=document.getElementById('email').value
     document.getElementById('show').textContent=uname + " "+ email
     alert('user aded')
}